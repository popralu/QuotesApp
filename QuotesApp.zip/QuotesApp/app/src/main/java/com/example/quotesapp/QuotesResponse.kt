package com.example.quotesapp

class QuotesResponse {
    var text : String = ""
    var author : String = ""

}