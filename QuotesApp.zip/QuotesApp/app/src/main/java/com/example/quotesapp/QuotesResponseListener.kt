package com.example.quotesapp

import android.os.Message

interface QuotesResponseListener {
    fun didFetch(response: List<QuotesResponse>, message: String)
    fun didError (message: String)
}