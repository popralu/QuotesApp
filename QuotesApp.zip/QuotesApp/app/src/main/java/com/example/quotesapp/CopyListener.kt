package com.example.quotesapp

interface CopyListener {
    fun onCopyCLicked(text : String)
}